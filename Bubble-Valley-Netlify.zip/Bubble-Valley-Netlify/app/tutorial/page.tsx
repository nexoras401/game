import Tutorial from '../../src/components/Tutorial';
import {currentAccount} from '../../src/server/hosting-backend';
import {redirect} from 'next/navigation';
export const dynamic='force-dynamic';
export default async function Page(){const account=await currentAccount();if(!account)redirect('/login');if(account.round)redirect('/jogo');return <Tutorial/>;}
