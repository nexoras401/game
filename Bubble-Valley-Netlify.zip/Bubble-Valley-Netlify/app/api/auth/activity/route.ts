import {proxyApi} from '../../../../src/server/hosting-backend';
export const dynamic='force-dynamic';
export const GET=proxyApi;
