import type {Metadata} from 'next';
import './globals.css';
import GlobalMusic from '../src/components/GlobalMusic';
import LiveRoundGuard from '../src/components/LiveRoundGuard';
export const metadata:Metadata={title:'Bubble Valley · Contas e partidas',description:'Bubble Shooter com conta e partidas salvas. Pagamentos aguardando integração.',icons:{icon:'/favicon.svg',shortcut:'/favicon.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body><GlobalMusic/><LiveRoundGuard/>{children}</body></html>;}
