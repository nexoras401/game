import AccountAccess from '../../src/components/AccountAccess';
import {currentIdentity} from '../../src/server/auth';
import {redirect} from 'next/navigation';
export const dynamic='force-dynamic';
export default async function Page(){if(await currentIdentity())redirect('/painel');return <AccountAccess signup/>;}
