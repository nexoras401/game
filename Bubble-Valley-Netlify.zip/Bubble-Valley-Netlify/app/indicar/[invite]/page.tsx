import {redirect,notFound} from 'next/navigation';
import {backendRead} from '../../../src/server/hosting-backend';
import {referralCodeFromPath} from '../../../src/referrals';
export const dynamic='force-dynamic';
export default async function Page({params}:{params:Promise<{invite:string}>}){const {invite}=await params,code=referralCodeFromPath(invite);if(!code)notFound();const result=await backendRead('/api/referrals/lookup?code='+code);if(!result?.exists)notFound();redirect('/cadastro?ref='+code);}
