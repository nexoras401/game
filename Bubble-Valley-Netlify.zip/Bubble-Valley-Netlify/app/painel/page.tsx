import {currentAccount} from '../../src/server/hosting-backend';
import LiveApp,{type Account} from '../../src/components/LiveApp';
import {redirect} from 'next/navigation';
export const dynamic='force-dynamic';
export default async function Page(){const account=await currentAccount();if(!account)redirect('/login');if(account.round)redirect('/jogo');return <LiveApp panel initialAccount={account as unknown as Account}/>;}
