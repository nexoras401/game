import AccountAccess from '../../src/components/AccountAccess';
import {currentAccount} from '../../src/server/hosting-backend';
import {redirect} from 'next/navigation';
export const dynamic='force-dynamic';
export default async function Page(){const account=await currentAccount();if(account?.isDemo)redirect('/painel');return <AccountAccess demo/>;}
