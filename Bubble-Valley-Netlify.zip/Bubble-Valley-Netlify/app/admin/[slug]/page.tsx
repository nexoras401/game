import {redirect,notFound} from 'next/navigation';
import {currentPartner} from '../../../src/server/partner-auth';
import PartnerLogin from '../../../src/components/PartnerLogin';
import AdminPanel from '../../../src/components/AdminPanel';
export const dynamic='force-dynamic';
export default async function Page({params}:{params:Promise<{slug:string}>}){const {slug}=await params;if(!['gabriel','bt','isaque'].includes(slug))notFound();const user=await currentPartner();if(user&&user.slug!==slug)redirect('/admin/'+user.slug);return user?<AdminPanel slug={slug}/>:<PartnerLogin slug={slug}/>;}
