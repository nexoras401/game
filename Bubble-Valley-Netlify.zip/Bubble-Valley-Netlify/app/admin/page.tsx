import {redirect} from 'next/navigation';
import {currentPartner} from '../../src/server/partner-auth';
export const dynamic='force-dynamic';
export default async function Page(){const user=await currentPartner();redirect('/admin/'+(user?.slug||'gabriel'));}
