# Bubble Valley — jogo e três painéis

React/TypeScript/Canvas, Vinext, Cloudflare Worker e D1. Cadastro de jogadores com telefone e senha persistidos no servidor, sem Supabase. Tutorial, carteira, indicações e partidas usam a mesma conta.

## Painéis individuais

- `/admin/gabriel`, usuário `gabriel`.
- `/admin/bt`, usuário `bt`.
- `/admin/isaque`, usuário `isaque`.

As senhas iniciais são entregues separadamente. Cada painel exige login próprio e apresenta somente sua rede de até três níveis, depósitos confirmados, comissões, demos e notificações. A hospedagem é pública, mas as APIs financeiras e administrativas exigem suas respectivas sessões. Nenhum cabeçalho de identidade da hospedagem libera o painel.

Compartilhe o link disponível em Indicados. A indicação é registrada no cadastro: acessar somente o painel ou enviar o endereço comum do jogo não atribui uma venda. Depósitos de contas antigas sem indicação não são atribuídos retroativamente. Depósitos confirmados são vendas; bônus não entram na base de comissão. Taxas são configuradas por beneficiário.

Senhas de parceiros usam PBKDF2-SHA256, salt individual e 100.000 iterações. Sessão administrativa de sete dias, inatividade máxima de um dia; somente o hash do token é armazenado. Cookies Secure, HttpOnly e SameSite=Lax. Alterar senha revoga outras sessões. Limites de tentativas e validação de origem protegem as mutações.

## Jogadores, partidas e Pix

Senhas de jogadores usam pepper secreto e PBKDF2-SHA256. Preserve `AUTH_PEPPER`: sua troca sem migração invalida as senhas e configurações criptografadas. Telefone não é verificado por SMS; recuperação por SMS não está implementada.

Saldo em centavos de BRL; resultado, tabuleiro e débito/crédito calculados pelo servidor. Carteiras e partidas possuem isolamento por conta, revisão otimista e idempotência. Demos têm saldo de teste e não aceitam depósitos reais. A demonstração hospedada original redireciona para `/demo` do principal.

BravoPay gera cobranças Pix no servidor usando `BRAVOPAY_API_KEY`. O saldo é creditado uma única vez após confirmação do provedor, incluindo bônus opcional de 100% exclusivamente nos valores R$100 e R$200. Consulta autenticada a cada cinco segundos enquanto a interface está aberta reconcilia cobranças. Para receber webhooks assinados, configure também `BRAVOPAY_WEBHOOK_SECRET` e o endpoint `/api/payments/webhook` no provedor; sem esse segredo webhooks são rejeitados. Os códigos não contêm chaves de produção nem o banco real.

Pedidos de saque de comissão reservam saldo e ficam pendentes; não executam transferência automática. Atividade fictícia é identificada como simulada e não compõe os registros financeiros.

## Notificações

Caixa de notificações separada por painel para cadastros, depósitos e comissões. Marcar como lida afeta somente a própria caixa. Cada pessoa pode configurar sua URL Pushcut em Notificações, criptografada no banco e omitida das respostas. O botão Testar valida o envio; eventos pendentes são processados nas operações do aplicativo e nas consultas ao painel. Não há trabalhador agendado independente: sem tráfego, o envio pode aguardar. URLs Pushcut precisam ser fornecidas pelos titulares.

## Desenvolvimento

Use Node 22.13 ou posterior e pnpm 11.25. Execute `pnpm install`, `pnpm exec tsc --noEmit --incremental false`, `node tests/server.mjs` e `pnpm build`. Configure Worker/D1 e aplique as migrações de `drizzle/` na ordem. Não abra o HTML como arquivo local. O segredo `AUTH_PEPPER` precisa ter pelo menos 32 caracteres; use chaves de teste fora de produção.

A migração 0006 cria os três parceiros com hashes das credenciais iniciais. Não reaplique migrações já executadas. Novas instalações devem substituir as senhas após o primeiro acesso.

56 suítes de servidor verificam contas, pagamentos, partidas, comissões, isolamento dos três painéis, credenciais e roteamento de notificações com transporte simulado. Testes HTTP do build verificaram logins, cookies, origem, logout e cadastro sem identidade da hospedagem. Isso não substitui validação visual em celulares nem comprova uma transferência bancária ou entrega real a um iPhone.
