declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    AUTH_PEPPER?: string;
    BRAVOPAY_API_KEY?: string;
    BRAVOPAY_WEBHOOK_SECRET?: string;
    BUCKET?: R2Bucket;
  }
}
