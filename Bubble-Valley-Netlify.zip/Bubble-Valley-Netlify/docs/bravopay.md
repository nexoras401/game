# BravoPay PIX

A integração gera PIX pelo servidor e credita o valor bruto pago na carteira do jogador. Taxas da adquirente pertencem ao comerciante. O bônus escolhido é calculado e salvo no servidor antes da cobrança. Nenhum clique, comprovante enviado ou resposta de criação libera saldo.

## Configuração necessária

No ambiente de produção do Sites, cadastrar como segredo `BRAVOPAY_API_KEY` (Dashboard BravoPay → API Keys). Não salvar o valor em arquivos, no Git, no navegador ou em `NEXT_PUBLIC_*`. Publicar uma versão depois de configurar para aplicar a revisão do ambiente. Preservar `AUTH_PEPPER` existente.

Para notificações externas, cadastrar em Dashboard BravoPay → Integrações o endpoint `/api/payments/webhook` do domínio do jogo e configurar seu segredo como `BRAVOPAY_WEBHOOK_SECRET`. O endpoint valida HMAC-SHA256 do corpo original, janela de cinco minutos e vínculo entre transação, referência, moeda e valor. A proteção privada do host pode impedir o gateway de chegar ao endpoint. Não remover essa proteção sem solicitação do proprietário. No site privado a consulta autenticada pelo servidor atualiza a carteira enquanto o jogador está com o jogo aberto; não depende de webhook acessível.

## Funcionamento

- PIX e código copia e cola na tela de depósito.
- Consultas em intervalos de cinco segundos com deduplicação entre abas e botão para consultar.
- Confirmação PAID, obtida por consulta autenticada ou webhook assinado, libera crédito.
- Migração 0003 registra intenções; trigger e lançamentos de extrato garantem crédito atômico único, inclusive em confirmação simultânea.
- R$ 100/200 podem conceder bônus de igual valor, conforme escolha anterior à cobrança.
- Retentativas reutilizam a referência e o identificador da cobrança. Solicitações ambíguas antigas não são recriadas depois da janela de idempotência do provedor.
- Reembolso/chargeback encaminha o depósito para conferência e impede novas apostas até reconciliação; não gera saldo novo.
- Saques continuam desabilitados. O endpoint BravoPay `/withdrawals` descrito na documentação é de saque da conta comercial, e não deve ser tratado como pagamento a qualquer jogador sem validar o produto de payout.

Antes de ativar, testar uma cobrança real pequena autorizada pelo proprietário, sua confirmação e uma entrega duplicada. Testes locais usam gateway simulado, nunca movimentam dinheiro real.
