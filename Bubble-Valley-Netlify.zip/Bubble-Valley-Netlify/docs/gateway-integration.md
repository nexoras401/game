# Integração do gateway pendente

Enviar o nome do provedor e a documentação oficial. As credenciais devem ser configuradas como segredos da hospedagem, nunca inseridas no frontend, Git ou mensagens.

## Contrato esperado

Valores inteiros em centavos; moeda BRL; referência única da ordem e chave de idempotência. Depósito: identificador da cobrança, Pix copia/cola e validade. Saque: identificador e estado pendente, seguido de confirmação verificável. Webhook: assinatura ou mecanismo oficial de autenticação, identificador único do evento, identificador da ordem, valor, moeda e estado final.

## Regras de ativação

1. Conferir suporte do provedor ao produto e configurar ambiente de testes.
2. Criar ordens persistentes e mapear eventos verificados somente para ordens existentes da mesma conta, moeda e valor; nunca aceitar usuário/valor diretamente como autorização de crédito.
3. Reservar saldo para saques em transação, devolvê-lo se falhar; nunca creditar ou debitar com base no retorno do navegador.
4. Aplicar eventos verificados e extrato em transação única; restrição única para evento e ordem evita pagamento duplicado.
5. Verificar eventos repetidos, fora de ordem, assinaturas inválidas, valores divergentes, falha de rede, expiração, estorno e concorrência.
6. Habilitar a interface somente após testes de ponta a ponta e revisão de operação. O adapter atual não efetua pagamentos.

Este documento especifica a próxima integração; não representa pagamentos implementados ou ativados.
