export const W=396,H=760,R=21.5,STEP=43,ROW=STEP*Math.sqrt(3)/2,TOP=214,DANGER=606,LAUNCH={x:W/2,y:700};
export type Point={x:number;y:number};
export type Bubble={r:number;c:number;type:number};
export type Status='playing'|'won'|'lost';
export type Effect={x:number;y:number;vx:number;vy:number;type:number;life:number;max:number;kind:'drop'|'pop'|'spark'};
export type GameEvent={name:string;count?:number;amount?:number};
export type Trace={points:Point[];hit:Bubble|null;end:Point};
export class GameEngine {
 queuedBubble=0;visualCurrent:number|null=null;visualNext:number|null=null;nextRow:number[]=[];grid:Bubble[]=[];parity=0;currentBubble=0;nextBubble=0;shotsUntilRow=2;progress=0;score=0;targetScore:number;status:Status='playing';combo=0;shots=0;effects:Effect[]=[];flight:{trace:Trace;distance:number;type:number}|null=null;events:GameEvent[]=[];shake=0;rowOffset=0;seed:number;popped=0;dropped=0;bombHit=false;exploded=false;rowAdded=false;gameOver=false;
 constructor(public entry=10,seed=Date.now(),public difficulty: 'standard'|'hard'|'endurance'|'expert'|'challenge'|'extreme'|'varied'='standard'){this.seed=seed>>>0;this.shotsUntilRow=this.pressureEvery();this.targetScore=entry*5;for(let r=0;r<2;r++)for(let c=0;c<this.columns(r);c++)this.grid.push({r,c,type:this.random()<this.obstacleChance()?6:this.difficulty==='varied'?this.mixedColor(r,c,this.grid,this.parity):Math.floor(this.random()*5)});this.currentBubble=this.availableColor();this.nextBubble=this.availableColor();this.prepareRow();this.prepareBubble();}
 random(){this.seed=(Math.imul(1664525,this.seed)+1013904223)>>>0;return this.seed/4294967296;}
 columns(r:number){return (r+this.parity)%2===0?9:8;}
 pos(b:Pick<Bubble,'r'|'c'>):Point{return {x:30+b.c*STEP+((b.r+this.parity)%2)*R,y:TOP+b.r*ROW};}
 neighbors(b:Bubble){const p=this.pos(b);return this.grid.filter(n=>n!==b&&Math.hypot(this.pos(n).x-p.x,this.pos(n).y-p.y)<STEP+1);}
 group(start:Bubble,condition:(b:Bubble)=>boolean){const found=new Set<Bubble>([start]),queue=[start];for(let i=0;i<queue.length;i++)for(const n of this.neighbors(queue[i]))if(!found.has(n)&&condition(n)){found.add(n);queue.push(n);}return [...found];}
 availableColor(){const colors=[...new Set(this.grid.filter(b=>b.type<5).map(b=>b.type))];return colors.length?colors[Math.floor(this.random()*colors.length)]:Math.floor(this.random()*3);}
 direction(target:Point){let dx=target.x-LAUNCH.x,dy=Math.min(-25,target.y-LAUNCH.y);const angle=Math.max(-1.35,Math.min(1.35,Math.atan2(dx,-dy)));return {x:Math.sin(angle),y:-Math.cos(angle)};}
 trace(target:Point):Trace {
  let p={...LAUNCH},v=this.direction(target);const points=[{...p}];let hit:Bubble|null=null;
  for(let bounce=0;bounce<12;bounce++){
   let best=(TOP-p.y)/v.y;let kind:'top'|'wall'|'bubble'='top';let bHit:Bubble|null=null;
   const wall=v.x>0?(W-R-p.x)/v.x:v.x<0?(R-p.x)/v.x:Infinity;
   if(wall>0.0001&&wall<best){best=wall;kind='wall';}
   for(const b of this.grid){const center=this.pos(b),dx=p.x-center.x,dy=p.y-center.y,B=dx*v.x+dy*v.y,C=dx*dx+dy*dy-(2*R-0.4)**2,disc=B*B-C;if(disc<0)continue;const t=-B-Math.sqrt(disc);if(t>0.0001&&t<best){best=t;kind='bubble';bHit=b;}}
   p={x:p.x+v.x*best,y:p.y+v.y*best};points.push({...p});
   if(kind!=='wall'){hit=bHit;break;}v.x=-v.x;p={x:p.x+v.x*.001,y:p.y};
  }
  return {points,hit,end:points[points.length-1]};
 }
 shoot(target:Point){if(this.status!=='playing'||this.flight)return false;this.flight={trace:this.trace(target),distance:0,type:this.currentBubble};this.events.push({name:'hit'});return true;}
 flightPoint(){if(!this.flight)return null;let distance=this.flight.distance;const points=this.flight.trace.points;for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],len=Math.hypot(b.x-a.x,b.y-a.y);if(distance<=len)return {x:a.x+(b.x-a.x)*distance/len,y:a.y+(b.y-a.y)*distance/len};distance-=len;}return points[points.length-1];}
 pathLength(t:Trace){return t.points.slice(1).reduce((sum,p,i)=>sum+Math.hypot(p.x-t.points[i].x,p.y-t.points[i].y),0);}
 swap(){if(this.status!=='playing'||this.flight)return;[this.currentBubble,this.nextBubble]=[this.nextBubble,this.currentBubble];this.events.push({name:'switch'});}
 snap(trace:Trace,type:number){
  const candidates:Bubble[]=[];const max=this.grid.length?Math.max(...this.grid.map(b=>b.r))+1:0;
  for(let r=0;r<=max;r++)for(let c=0;c<this.columns(r);c++){if(this.grid.some(b=>b.r===r&&b.c===c))continue;const cell={r,c,type};if(r===0||this.neighbors(cell).length)candidates.push(cell);}
  const valid=trace.hit?candidates.filter(b=>Math.hypot(this.pos(b).x-this.pos(trace.hit!).x,this.pos(b).y-this.pos(trace.hit!).y)<=STEP+1):candidates.filter(b=>b.r===0);
  const choices=valid.length?valid:candidates;
  return choices.sort((a,b)=>Math.hypot(this.pos(a).x-trace.end.x,this.pos(a).y-trace.end.y)-Math.hypot(this.pos(b).x-trace.end.x,this.pos(b).y-trace.end.y))[0];
 }
 burst(b:Bubble,kind:'pop'|'drop'){const p=this.pos(b);this.effects.push({...p,vx:(this.random()-.5)*110,vy:kind==='drop'?-60:0,type:b.type,life:kind==='drop'?3:.38,max:kind==='drop'?3:.38,kind});if(kind==='pop')for(let k=0;k<7;k++){const angle=this.random()*Math.PI*2,speed=40+this.random()*180;this.effects.push({...p,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed,type:b.type,life:.5,max:.5,kind:'spark'});}}
 remove(list:Bubble[],kind:'pop'|'drop'){for(const b of list)this.burst(b,kind);const set=new Set(list);this.grid=this.grid.filter(b=>!set.has(b));}
 detached(){const attached=new Set<Bubble>();for(const top of this.grid.filter(b=>b.r===0))for(const b of this.group(top,()=>true))attached.add(b);return this.grid.filter(b=>!attached.has(b));}
 pressureEvery(){return this.difficulty==='endurance'||this.difficulty==='expert'||this.difficulty==='challenge'||this.difficulty==='extreme'||this.difficulty==='varied'?3:2;}
 obstacleChance(){return this.difficulty==='varied'?.05:this.difficulty==='extreme'?.28:this.difficulty==='challenge'?.14:this.difficulty!=='standard'?.08:.025;}
 bombEvery(){return this.difficulty==='varied'?32:this.difficulty==='extreme'?40:this.difficulty==='challenge'?32:this.difficulty!=='standard'?24:12;}
 prepareBubble(){this.queuedBubble=(this.shots+1)%this.bombEvery()===0?5:this.availableColor();}
 mixedColor(r:number,c:number,board:Bubble[],parity:number){
  const pos=(b:Pick<Bubble,'r'|'c'>)=>({x:30+b.c*STEP+((b.r+parity)%2)*R,y:TOP+b.r*ROW});
  const neighbors=(b:Pick<Bubble,'r'|'c'>)=>{const p=pos(b);return board.filter(n=>n!==b&&Math.hypot(pos(n).x-p.x,pos(n).y-p.y)<STEP+1);};
  const options:number[]=[];
  for(let color=0;color<5;color++){const queue=neighbors({r,c}).filter(b=>b.type===color),seen=new Set<Bubble>();for(let i=0;i<queue.length&&seen.size<2;i++){const b=queue[i];if(seen.has(b))continue;seen.add(b);for(const n of neighbors(b))if(n.type===color&&!seen.has(n))queue.push(n);}if(seen.size<2)options.push(color);}
  const choices=options.length?options:[0,1,2,3,4];return choices[Math.floor(this.random()*choices.length)];
 }
 prepareRow(){
  if(this.difficulty!=='varied'){this.nextRow=Array.from({length:this.parity===0?8:9},()=>this.difficulty!=='standard'&&this.random()<this.obstacleChance()?6:Math.floor(this.random()*5));return;}
  const parity=1-this.parity,board=this.grid.map(b=>({...b,r:b.r+1}));this.nextRow=[];
  for(let c=0;c<(parity===0?9:8);c++){const type=this.random()<this.obstacleChance()?6:this.mixedColor(0,c,board,parity);this.nextRow.push(type);board.push({r:0,c,type});}
 }

 previewImpact(trace:Trace,type:number){
  // Presentation only. Wallet, score, turn, launcher and result remain authoritative.
  const saved={score:this.score,progress:this.progress,shots:this.shots,shotsUntilRow:this.shotsUntilRow,currentBubble:this.currentBubble,nextBubble:this.nextBubble,combo:this.combo,status:this.status,gameOver:this.gameOver,seed:this.seed,queuedBubble:this.queuedBubble,nextRow:[...this.nextRow],events:this.events};
  this.events=[];this.resolve(trace,type);const result={events:this.events,combo:this.combo};Object.assign(this,saved);this.visualCurrent=saved.nextBubble;this.visualNext=saved.queuedBubble;return result;
 }
 resolve(trace:Trace,type:number){
  this.popped=0;this.dropped=0;this.bombHit=false;this.exploded=false;this.rowAdded=false;
  const placed=this.snap(trace,type);if(!placed){this.lose();return;}this.grid.push(placed);let removed:Bubble[]=[];
  if(type===5||trace.hit?.type===5){this.bombHit=true;this.exploded=true;const p=this.pos(trace.hit?.type===5?trace.hit:placed);removed=this.grid.filter(b=>Math.hypot(this.pos(b).x-p.x,this.pos(b).y-p.y)<=STEP*2.2);this.shake=.35;this.events.push({name:'bomb'});}
  else if(type<5){const group=this.group(placed,b=>b.type===type);if(group.length>=3)removed=group;}
  if(removed.length){this.popped=removed.length;this.remove(removed,'pop');const floating=this.detached();this.dropped=floating.length;this.remove(floating,'drop');this.combo++;const amount=Math.round(this.entry*(removed.length*.2+floating.length*.3)*Math.min(this.difficulty==='expert'||this.difficulty==='challenge'||this.difficulty==='extreme'||this.difficulty==='varied'?1.1:this.difficulty==='endurance'?1.15:this.difficulty==='hard'?1.2:1.5,1+(this.combo-1)*.1)*(this.difficulty==='expert'||this.difficulty==='challenge'||this.difficulty==='extreme'||this.difficulty==='varied'?.18:this.difficulty==='endurance'?.25:this.difficulty==='hard'?.45:1)*100)/100;this.score=Math.round((this.score+amount)*100)/100;this.progress=Math.min(1,this.score/this.targetScore);this.events.push({name:this.bombHit?'Boom!':(removed.length+floating.length<=3?'Good!':removed.length+floating.length<=4?'Cool!':removed.length+floating.length<=5?'Strong!':removed.length+floating.length<=7?'Awesome!':removed.length+floating.length<=9?'Amazing!':'Best!'),count:removed.length+floating.length,amount},{name:'broken'});}
  else{this.combo=0;this.events.push({name:'encaixe'});}
  this.shots++;this.shotsUntilRow=this.pressureEvery()-(this.shots%this.pressureEvery());this.currentBubble=this.nextBubble;this.nextBubble=this.queuedBubble;
  
  if(this.shots%this.pressureEvery()===0)this.addRow();
  if(this.grid.some(b=>this.pos(b).y+R>=DANGER))this.lose();this.prepareBubble();
 }
 addRow(){const colors=[...this.nextRow];for(const b of this.grid)b.r++;this.parity=1-this.parity;for(let c=0;c<this.columns(0);c++)this.grid.push({r:0,c,type:colors[c]??Math.floor(this.random()*5)});this.prepareRow();this.shotsUntilRow=this.pressureEvery();this.rowOffset=-ROW;this.rowAdded=true;this.events.push({name:'selection'});}

 canClaim(){return this.status==='playing'&&this.score>=this.targetScore&&!this.flight;}
 cashOut(){if(!this.canClaim())throw Error('Resgate disponível após atingir a meta e concluir o disparo.');this.status='won';this.gameOver=true;this.events.push({name:'win'});return this.score;}
 lose(){this.status='lost';this.gameOver=true;this.remove([...this.grid],'drop');this.events.push({name:'defeat'});}
 update(dt:number){this.shake=Math.max(0,this.shake-dt);this.rowOffset*=Math.exp(-dt*12);for(const e of this.effects){e.life-=dt;e.x+=e.vx*dt;e.y+=e.vy*dt;if(e.kind==='drop'||e.kind==='spark')e.vy+=dt*1350;}this.effects=this.effects.filter(e=>e.life>0&&e.y<H+100);if(this.flight){this.flight.distance+=dt*1500;if(this.flight.distance>=this.pathLength(this.flight.trace)){const shot=this.flight;this.flight=null;this.resolve(shot.trace,shot.type);}}}
}
