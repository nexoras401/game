import {GameEngine,W,H,R,DANGER,LAUNCH,Point} from './GameEngine';
const colors=[['#fff39c','#ffab16','#b74300'],['#ffc0a6','#ff3426','#a50017'],['#deff8f','#8dea18','#228500'],['#d9c3ff','#a34ffe','#4d0f98'],['#a9f7ff','#25c0ef','#004da0'],['#a79ba7','#423849','#140c24'],['#e2d5bd','#928576','#4e483e']];
export function drawBubble(ctx:CanvasRenderingContext2D,x:number,y:number,type:number,r=R,alpha=1){
 ctx.save();ctx.globalAlpha=alpha;const col=colors[type]||colors[0];
 const body=ctx.createRadialGradient(x-r*.34,y-r*.39,r*.06,x+r*.14,y+r*.25,r*1.12);
 body.addColorStop(0,type===1?'#ff9c6b':col[0]);body.addColorStop(.22,col[1]);body.addColorStop(.65,type===0?'#e76100':type===1?'#e81409':col[1]);body.addColorStop(1,col[2]);
 ctx.shadowColor='rgba(31,11,39,.35)';ctx.shadowBlur=2;ctx.shadowOffsetY=1;ctx.fillStyle=body;ctx.beginPath();ctx.arc(x,y,r*.95,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.shadowOffsetY=0;
 ctx.lineWidth=r*.065;ctx.strokeStyle=type===6?'#e5dac4':col[0];ctx.stroke();
 ctx.beginPath();ctx.arc(x,y,r*.82,0,Math.PI*2);ctx.lineWidth=r*.055;ctx.strokeStyle=type===1?'#6c0502':type===6?'#6c6659':col[2];ctx.stroke();
 ctx.beginPath();ctx.arc(x-r*.035,y-r*.025,r*.76,.2,Math.PI*.94);ctx.strokeStyle=type===1?'#ff6544':col[0];ctx.lineWidth=r*.035;ctx.stroke();
 if(type===6){
  ctx.save();ctx.beginPath();ctx.arc(x,y,r*.89,0,Math.PI*2);ctx.clip();
  const facets=[{p:[[-.8,-.45],[-.42,-.86],[.02,-.68],[.12,-.2],[-.3,.08],[-.69,-.07]],color:'#b5b0a1'},{p:[[.02,-.68],[.52,-.82],[.87,-.39],[.58,.04],[.12,-.2]],color:'#827f77'},{p:[[-.3,.08],[.12,-.2],[.58,.04],[.42,.53],[-.1,.69],[-.44,.43]],color:'#a39b8d'},{p:[[-.8,-.45],[-.69,-.07],[-.44,.43],[-.7,.76],[-1,.24]],color:'#776f60'},{p:[[.58,.04],[.87,-.39],[1,.13],[.75,.68],[.42,.53]],color:'#5f5b52'},{p:[[-.1,.69],[.42,.53],[.75,.68],[.36,1],[-.35,.97]],color:'#c1b8a7'}];
  for(const facet of facets){ctx.beginPath();facet.p.forEach(([px,py],i)=>i?ctx.lineTo(x+px*r,y+py*r):ctx.moveTo(x+px*r,y+py*r));ctx.closePath();ctx.fillStyle=facet.color;ctx.fill();ctx.strokeStyle='#4b473e';ctx.lineWidth=r*.052;ctx.stroke();ctx.strokeStyle='#d1c9b7';ctx.lineWidth=r*.018;ctx.stroke();}ctx.restore();
 }else if(type===5){ctx.font=`bold ${r*1.3}px sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#ffe8ab';ctx.shadowColor='#fb651c';ctx.shadowBlur=r*.35;ctx.fillText('✦',x,y+1);ctx.shadowBlur=0;}
 else if(type!==1){for(let i=0;i<3;i++){ctx.save();ctx.translate(x,y);ctx.rotate(i*Math.PI*2/3);ctx.beginPath();ctx.moveTo(-r*.06,-r*.66);ctx.bezierCurveTo(r*.38,-r*.74,r*.69,-r*.32,r*.39,-r*.05);ctx.bezierCurveTo(r*.18,r*.16,-r*.04,-r*.03,r*.12,-r*.16);ctx.bezierCurveTo(r*.22,-r*.24,r*.35,-r*.16,r*.28,-r*.07);ctx.lineCap='round';ctx.strokeStyle=col[2];ctx.lineWidth=r*.21;ctx.stroke();ctx.strokeStyle=col[0];ctx.lineWidth=r*.12;ctx.stroke();ctx.restore();}}
 const shine=ctx.createRadialGradient(x-r*.35,y-r*.57,0,x-r*.35,y-r*.57,r*.3);shine.addColorStop(0,'rgba(255,255,255,.96)');shine.addColorStop(.55,'rgba(255,255,255,.65)');shine.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=shine;ctx.beginPath();ctx.ellipse(x-r*.35,y-r*.57,r*.27,r*.16,-.55,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='rgba(255,255,255,.65)';ctx.beginPath();ctx.arc(x+r*.57,y+r*.45,r*.055,0,Math.PI*2);ctx.fill();ctx.restore();
}
export function render(ctx:CanvasRenderingContext2D,engine:GameEngine,aim:Point|null,time:number){
 ctx.clearRect(0,0,W,H);ctx.save();if(engine.shake)ctx.translate(Math.sin(time*90)*engine.shake*12,Math.cos(time*80)*engine.shake*8);
 ctx.strokeStyle='rgba(255,85,95,.8)';ctx.lineWidth=1.5;ctx.setLineDash([7,7]);ctx.beginPath();ctx.moveTo(14,DANGER);ctx.lineTo(W-14,DANGER);ctx.stroke();ctx.setLineDash([]);
 if(aim&&engine.status==='playing'&&!engine.flight){const trace=engine.trace(aim);ctx.fillStyle='#fffce2';let carry=0;for(let k=1;k<trace.points.length;k++){const a=trace.points[k-1],b=trace.points[k],len=Math.hypot(b.x-a.x,b.y-a.y);for(let d=carry;d<len;d+=13){ctx.globalAlpha=.72;ctx.beginPath();ctx.arc(a.x+(b.x-a.x)*d/len,a.y+(b.y-a.y)*d/len,2.2,0,Math.PI*2);ctx.fill();}carry=(carry-len)%13;if(carry<0)carry+=13;}ctx.globalAlpha=.4;const cell=engine.snap(trace,engine.currentBubble);if(cell){const p=engine.pos(cell);drawBubble(ctx,p.x,p.y,engine.currentBubble,R,.35);}ctx.globalAlpha=1;}
 for(const b of engine.grid){const p=engine.pos(b);drawBubble(ctx,p.x,p.y+engine.rowOffset,b.type);}
 for(const e of engine.effects){if(e.kind==='spark'){ctx.fillStyle=colors[e.type]?.[0]||'#fff';ctx.globalAlpha=Math.max(0,e.life/e.max);ctx.beginPath();ctx.arc(e.x,e.y,3*e.life/e.max,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}else drawBubble(ctx,e.x,e.y,e.type,R*(e.kind==='pop'?1+(1-e.life/e.max)*.4:1),e.kind==='pop'?e.life/e.max:Math.min(1,e.life));}
 const flying=engine.flightPoint();if(flying&&engine.flight)drawBubble(ctx,flying.x,flying.y,engine.flight.type);
 ctx.fillStyle='rgba(25,12,49,.36)';ctx.beginPath();ctx.ellipse(LAUNCH.x,LAUNCH.y+31,40,10,0,0,Math.PI*2);ctx.fill();ctx.strokeStyle='rgba(255,226,166,.65)';ctx.lineWidth=1.4;ctx.beginPath();ctx.arc(LAUNCH.x,LAUNCH.y,R+5,0,Math.PI*2);ctx.stroke();if(!engine.flight)drawBubble(ctx,LAUNCH.x,LAUNCH.y,engine.visualCurrent??engine.currentBubble,R+2);
 drawBubble(ctx,LAUNCH.x+74,LAUNCH.y-2,engine.visualNext??engine.nextBubble,R*.62);ctx.font='bold 11px sans-serif';ctx.fillStyle='#fff5de';ctx.textAlign='center';ctx.fillText('PRÓXIMA',LAUNCH.x+74,LAUNCH.y+22);ctx.restore();
}
