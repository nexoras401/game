import {GameEngine} from './GameEngine';
export const SHOT_SPEED=1700;
export function advancePresentation(engine:GameEngine,dt:number){
 const flight=engine.flight;engine.flight=null;engine.update(dt);engine.flight=flight;
 if(!flight)return null;flight.distance=Math.min(engine.pathLength(flight.trace),flight.distance+dt*SHOT_SPEED);
 if(flight.distance<engine.pathLength(flight.trace))return null;
 engine.flight=null;return engine.previewImpact(flight.trace,flight.type);
}
