export function referralPath(name:string,code:string){
 const slug=name.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,60)||'jogador';
 if(!/^[a-z0-9]{12}$/.test(code))throw Error('Código de indicação inválido.');
 return `/indicar/bubble-valley-${slug}-${code}`;
}
export function referralCodeFromPath(value:string){return value.length<=120&&/^bubble-valley-[a-z0-9-]+-[a-z0-9]{12}$/.test(value)?value.slice(-12):null;}
