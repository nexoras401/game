import {cookies} from 'next/headers';
import {backendRead} from './hosting-backend';
export async function currentPartner(){return (await cookies()).has('__Host-bv_partner')?backendRead('/api/partners/session'):null;}
