export function depositQuote(amountCents:unknown,useBonus:unknown=false){
 if(typeof amountCents!=='number'||!Number.isSafeInteger(amountCents)||amountCents<2000||amountCents>1000000)throw Error('Informe um depósito entre R$ 20 e R$ 10.000.');
 if(typeof useBonus!=='boolean')throw Error('Escolha se deseja usar o bônus.');
 const eligible=amountCents===10000||amountCents===20000,bonusCents=eligible&&useBonus?amountCents:0;
 return {amountCents,useBonus:eligible&&useBonus,bonusCents,totalCents:amountCents+bonusCents};
}
