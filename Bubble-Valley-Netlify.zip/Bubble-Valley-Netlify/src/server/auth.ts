import {currentAccount} from './hosting-backend';
export async function currentIdentity(){const account=await currentAccount();return account?{userId:'authenticated',displayName:account.profile.name}:null;}
