import {cookies} from 'next/headers';
import type {Account} from '../components/LiveApp';

// Server-only origin. The existing backend retains the database and gateway secrets.
function backend(){const raw=process.env.BUBBLE_BACKEND_ORIGIN;if(!raw)throw new Error('Configure BUBBLE_BACKEND_ORIGIN.');const url=new URL(raw);if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash)throw new Error('Invalid backend origin.');return url.origin;}
export async function backendRead(path:string){const store=await cookies();const headers=new Headers();const valid=[];for(const name of ['__Host-bv_session','__Host-bv_partner']){const value=store.get(name)?.value;if(value&&/^[a-f0-9]{64}$/.test(value))valid.push(name+'='+value);}if(valid.length)headers.set('Cookie',valid.join('; '));const response=await fetch(backend()+path,{headers,cache:'no-store',redirect:'error',signal:AbortSignal.timeout(12000)});if(response.status===401||response.status===403)return null;if(!response.ok)throw new Error('Backend unavailable.');return response.json();}
export const currentAccount=async()=>(await cookies()).has('__Host-bv_session')?await backendRead('/api/account') as Account|null:null;
export async function proxyApi(request:Request){
 const url=new URL(request.url),target=backend();
 const changing=!['GET','HEAD'].includes(request.method);
 if(changing&&url.pathname!=='/api/payments/webhook'){
  const origin=request.headers.get('origin'),site=request.headers.get('sec-fetch-site');
  if(origin!==url.origin||(site&&site!=='same-origin'&&site!=='none'))return Response.json({error:'Origem inválida.'},{status:403});
 }
 const headers=new Headers();
 for(const name of ['content-type','bravopay-signature','x-bravopay-signature']){const value=request.headers.get(name);if(value)headers.set(name,value);}
 const incoming=request.headers.get('cookie')||'';const allowed=incoming.split(';').map(v=>v.trim()).filter(v=>/^__Host-bv_(session|partner)=[a-f0-9]{64}$/.test(v));if(allowed.length)headers.set('Cookie',allowed.join('; '));
 if(changing&&url.pathname!=='/api/payments/webhook')headers.set('origin',target);
 try{
  const max=url.pathname==='/api/payments/webhook'?65536:4096;const declared=request.headers.get('content-length');if(declared&&Number(declared)>max)return Response.json({error:'Solicitação muito grande.'},{status:413});
  let payload:Uint8Array<ArrayBuffer>|undefined;
  if(changing&&request.body){const reader=request.body.getReader(),parts:Uint8Array[]=[];let size=0;try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>max){await reader.cancel();return Response.json({error:'Solicitação muito grande.'},{status:413});}parts.push(value);}payload=new Uint8Array(size);let offset=0;for(const part of parts){payload.set(part,offset);offset+=part.byteLength;}}finally{reader.releaseLock();}}
  const response=await fetch(target+url.pathname+url.search,{method:request.method,headers,body:payload,cache:'no-store',redirect:'manual',signal:AbortSignal.timeout(20000)});
  const returned=new Headers({'Cache-Control':'private, no-store','Content-Type':response.headers.get('content-type')||'application/json'});
  for(const cookie of response.headers.getSetCookie())returned.append('Set-Cookie',cookie);
  const location=response.headers.get('location');if(location){const redirect=new URL(location,target);if(redirect.origin!==target)return Response.json({error:'Redirecionamento inválido.'},{status:502});returned.set('Location',redirect.pathname+redirect.search);}
  return new Response(response.body,{status:response.status,headers:returned});
 }catch{return Response.json({error:'Serviço indisponível. Tente novamente.'},{status:503,headers:{'Cache-Control':'no-store'}});}
}
