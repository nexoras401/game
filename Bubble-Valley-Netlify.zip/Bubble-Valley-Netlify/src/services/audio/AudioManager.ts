// Original Web Audio instruments. Audio is activated by a user gesture.
export class AudioManager {
 static musicOwner:AudioManager|null=null;
 ctx:AudioContext|null=null;muted=false;music=false;timer:ReturnType<typeof setInterval>|null=null;step=0;master:GainNode|null=null;
 constructor(){try{this.muted=localStorage.getItem('bubble.muted')==='true';}catch{}}
 init(){if(!this.ctx){this.ctx=new AudioContext();this.master=this.ctx.createGain();this.master.gain.value=.55;const compressor=this.ctx.createDynamicsCompressor();this.master.connect(compressor);compressor.connect(this.ctx.destination);}void this.ctx.resume();}
 tone(freq:number,duration=.12,volume=.06,type:OscillatorType='sine',delay=0,end=freq){if(!this.ctx||this.muted||!this.master)return;const osc=this.ctx.createOscillator(),gain=this.ctx.createGain(),now=this.ctx.currentTime+delay;osc.type=type;osc.frequency.setValueAtTime(freq,now);osc.frequency.exponentialRampToValueAtTime(Math.max(35,end),now+duration);gain.gain.setValueAtTime(.0001,now);gain.gain.linearRampToValueAtTime(volume,now+.008);gain.gain.exponentialRampToValueAtTime(.0001,now+duration);osc.connect(gain);gain.connect(this.master);osc.start(now);osc.stop(now+duration+.02);}
 play(name:string){if(this.muted)return;if(name==='selection'){this.tone(880,.085,.09,'sine',0,1320);this.tone(1760,.08,.025,'sine',.015);}
 else if(name==='hit'){this.tone(650,.14,.1,'sine',0,180);}
 else if(name==='broken'){this.tone(1100,.09,.065,'sine',0,520);this.tone(1568,.13,.035,'triangle',.025,784);}
 else if(name==='encaixe'){this.tone(270,.08,.065,'sine',0,120);}
 else if(name==='switch'){this.tone(440,.12,.06,'triangle',0,880);this.tone(880,.12,.04,'sine',.06,440);}
 else if(name==='defeat'){[392,330,262,196].forEach((f,i)=>this.tone(f,.32,.08,'triangle',i*.16));}
 else if(name==='bomb'){this.tone(110,.5,.17,'triangle',0,35);this.tone(440,.12,.06,'sine',0,60);}
 else if(name==='win'||name==='demo-success'){[523,659,784,1046,1318].forEach((f,i)=>{this.tone(f,.45,.075,'triangle',i*.09);this.tone(f*2,.3,.025,'sine',i*.09);});}
 else{const combos=['Good!','Cool!','Strong!','Awesome!','Amazing!','Best!','Boom!'];const n=Math.max(0,combos.indexOf(name));[523,659,784,1046].slice(0,Math.min(4,2+n)).forEach((f,i)=>this.tone(f*2**(n/12),.23,.06,'sine',i*.055));}}
 combo(sequence:number,count:number){const base=523*2**(Math.min(7,Math.max(0,sequence-1))/12);[1,1.25,1.5,2].forEach((ratio,i)=>{this.tone(base*ratio,.24,.065,'sine',i*.045);this.tone(base*ratio*2,.14,.018,'triangle',i*.045);});this.tone(180+Math.min(count,12)*15,.09,.05,'sine',0,65);}
 toggle(){this.muted=!this.muted;try{localStorage.setItem('bubble.muted',String(this.muted));}catch{}window.dispatchEvent(new Event('bubble-audio-change'));return this.muted;}
 startMusic(){if(this.timer||AudioManager.musicOwner&&AudioManager.musicOwner!==this)return;AudioManager.musicOwner=this;this.music=true;
 // Original relaxed 90 BPM composition: soft keys, warm chords and a light bass.
 const notes=[523,659,784,0,659,587,523,0,440,523,659,0,587,523,440,0,349,440,523,0,659,587,523,0,392,494,587,0,659,587,494,0];
 const chords=[[131,165,196],[110,131,165],[87,110,131],[98,123,147]];
 const tick=()=>{const i=this.step++%32;if(notes[i]){this.tone(notes[i],.48,.023,'sine');this.tone(notes[i]*2,.22,.004,'triangle');}if(i%8===0){const chord=chords[Math.floor(i/8)];chord.forEach((f,n)=>this.tone(f*2,2.2,.008,'sine',n*.025));this.tone(chord[0],.9,.022,'sine');}else if(i%4===0)this.tone(chords[Math.floor(i/8)][0],.5,.012,'sine');};tick();this.timer=setInterval(tick,333);
 }
 stopMusic(){if(AudioManager.musicOwner===this)AudioManager.musicOwner=null;if(this.timer)clearInterval(this.timer);this.timer=null;this.music=false;}
 dispose(){this.stopMusic();void this.ctx?.close();}
}
