export type TutorialVoiceStep=0|1|2|3|4;
const files:Record<TutorialVoiceStep,string>={0:'/audio/welcome-valley.mp3',1:'/audio/tutorial-1.mp3',2:'/audio/tutorial-2.mp3',3:'/audio/tutorial-3.mp3',4:'/audio/tutorial-4.mp3'};
// One player queues the numbered instructions in order, even when combos arrive quickly.
export class TutorialVoice {
 private queue:TutorialVoiceStep[]=[];private active=false;private revision=0;private disposed=false;private latest:TutorialVoiceStep=0;
 private ended=()=>{this.active=false;this.next();};
 private failed=()=>{this.active=false;this.queue=[];this.unavailable(true);};
 constructor(private player:HTMLAudioElement,private muted:boolean,private unavailable:(value:boolean)=>void){player.preload='auto';player.volume=.9;player.addEventListener('ended',this.ended);player.addEventListener('error',this.failed);}
 private next(){if(this.disposed||this.muted||this.active||!this.queue.length)return;const step=this.queue.shift()!;this.active=true;const revision=++this.revision;this.player.src=files[step];this.player.currentTime=0;void this.player.play().then(()=>{if(revision===this.revision&&!this.disposed)this.unavailable(false);}).catch(()=>{if(revision===this.revision&&!this.disposed)this.failed();});}
 enqueue(step:TutorialVoiceStep){this.latest=step;if(this.disposed||this.muted)return;this.queue.push(step);this.next();}
 replay(step:TutorialVoiceStep=this.latest){this.stop();this.enqueue(step);}
 setMuted(muted:boolean){this.muted=muted;if(muted)this.stop();else this.replay();}
 stop(){++this.revision;this.queue=[];this.active=false;this.player.pause();this.player.currentTime=0;}
 dispose(){this.stop();this.disposed=true;this.player.removeEventListener('ended',this.ended);this.player.removeEventListener('error',this.failed);this.player.removeAttribute('src');this.player.load();}
}
