export interface DepositService {request(amountCents:number):Promise<{id:string;status:string}>;}
