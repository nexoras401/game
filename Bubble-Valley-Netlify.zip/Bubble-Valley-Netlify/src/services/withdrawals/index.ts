export interface WithdrawalService {request(amountCents:number):Promise<{id:string;status:string}>;}
