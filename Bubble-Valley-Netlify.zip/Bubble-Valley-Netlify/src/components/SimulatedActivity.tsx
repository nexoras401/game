'use client';
import {useEffect,useState} from 'react';
import {createPortal} from 'react-dom';
const examples=[{name:'Gabriel',action:'depositou',amount:50},{name:'Ruan',action:'sacou',amount:198.77},{name:'Isabella',action:'depositou',amount:100},{name:'Lucas',action:'sacou',amount:87.50},{name:'Camila',action:'depositou',amount:30},{name:'Mariana',action:'sacou',amount:125.20}];
// Presentation-only fixtures: never sent to account, payment or wallet APIs.
export default function SimulatedActivity(){
 const [online,setOnline]=useState(976),[index,setIndex]=useState(0),[visible,setVisible]=useState(false),[mounted,setMounted]=useState(false);
 useEffect(()=>{setMounted(true);let hide:ReturnType<typeof setTimeout>|undefined;let next=0;const show=()=>{if(document.hidden)return;setIndex(next++%examples.length);setVisible(true);hide=setTimeout(()=>setVisible(false),5500);};const first=setTimeout(show,2200),notifications=setInterval(show,10500),counter=setInterval(()=>{if(!document.hidden)setOnline(n=>Math.max(900,Math.min(1040,n+(Math.random()<.5?-1:1)*(1+Math.floor(Math.random()*7)))));},6000);return()=>{clearTimeout(first);if(hide)clearTimeout(hide);clearInterval(notifications);clearInterval(counter);};},[]);
 const item=examples[index];
 return <><span className="simulated-online"><span><i/>{online.toLocaleString('pt-BR')} online</span><small>Atividade simulada</small></span>{mounted&&createPortal(<aside className={`simulated-prize ${visible?'is-visible':''}`} aria-hidden={!visible}><span className="simulated-prize-icon" aria-hidden="true">{item.action==='depositou'?'↓':'↑'}</span><div><strong>{item.name}</strong><span>{item.action} · exemplo</span><small>Atividade simulada</small></div><b>{item.amount.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</b></aside>,document.body)}</>;
}
