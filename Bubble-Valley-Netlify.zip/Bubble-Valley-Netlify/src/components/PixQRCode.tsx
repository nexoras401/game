'use client';
import {useEffect,useRef,useState} from 'react';
export default function PixQRCode({code}:{code:string}){
 const canvas=useRef<HTMLCanvasElement>(null),[failed,setFailed]=useState(false);
 useEffect(()=>{let disposed=false;setFailed(false);import('qrcode').then(qr=>{if(!disposed&&canvas.current)return qr.toCanvas(canvas.current,code,{width:288,margin:4,errorCorrectionLevel:'M',color:{dark:'#000000',light:'#ffffff'}});}).catch(()=>{if(!disposed)setFailed(true);});return()=>{disposed=true;};},[code]);
 return <div className="pix-qr-box">{failed?<p>Use o código Pix copia e cola abaixo.</p>:<><canvas ref={canvas} role="img" aria-label="QR Code para pagar o depósito com Pix"/><small>Escaneie no aplicativo do seu banco</small></>}</div>;
}
