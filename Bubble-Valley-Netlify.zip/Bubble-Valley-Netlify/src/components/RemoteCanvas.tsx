'use client';
import {useEffect,useRef} from 'react';
import {GameEngine,W,H,LAUNCH,type Point,type GameEvent} from '../game/GameEngine';
import {advancePresentation} from '../game/presentation';
import {render} from '../game/Renderer';
export default function RemoteCanvas({engine,locked,onShoot,onImpact}:{engine:GameEngine;locked:boolean;onShoot:(p:Point)=>void;onImpact:(events:GameEvent[],combo:number)=>void}){
 const canvas=useRef<HTMLCanvasElement>(null),aim=useRef<Point|null>(null),dragging=useRef(false),shoot=useRef(onShoot);shoot.current=onShoot;const impact=useRef(onImpact);impact.current=onImpact;
 useEffect(()=>{const el=canvas.current!,ctx=el.getContext('2d')!;let frame=0,last=0;const resize=()=>{const box=el.getBoundingClientRect(),ratio=Math.min(2,window.devicePixelRatio||1);el.width=Math.round(box.width*ratio);el.height=Math.round(box.height*ratio);ctx.setTransform(el.width/W,0,0,el.height/H,0,0);};const observer=new ResizeObserver(resize);observer.observe(el);resize();const tick=(time:number)=>{const dt=last?Math.min(.035,(time-last)/1000):0;last=time;
  const result=advancePresentation(engine,dt);if(result)impact.current(result.events,result.combo);
  render(ctx,engine,aim.current,time/1000);frame=requestAnimationFrame(tick);};frame=requestAnimationFrame(tick);return()=>{cancelAnimationFrame(frame);observer.disconnect();};},[engine]);
 const position=(e:React.PointerEvent<HTMLCanvasElement>)=>{const box=e.currentTarget.getBoundingClientRect();return {x:Math.max(0,Math.min(W,(e.clientX-box.left)/box.width*W)),y:Math.max(0,Math.min(606,(e.clientY-box.top)/box.height*H))};};
 return <canvas ref={canvas} className="game-canvas" aria-label="Arraste para mirar e solte para disparar. Setas para mirar e espaço para disparar." tabIndex={0} onPointerDown={e=>{if(locked||engine.status!=='playing')return;e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);dragging.current=true;aim.current=position(e);}} onPointerMove={e=>{if(dragging.current)aim.current=position(e);}} onPointerUp={e=>{if(dragging.current&&!locked)shoot.current(position(e));dragging.current=false;aim.current=null;}} onPointerCancel={()=>{dragging.current=false;aim.current=null;}} onKeyDown={e=>{if(locked)return;const p=aim.current||{x:LAUNCH.x,y:350};if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();aim.current={x:Math.max(0,Math.min(W,p.x+(e.key==='ArrowLeft'?-25:25))),y:p.y};}if(e.key===' '||e.key==='Enter'){e.preventDefault();shoot.current(p);aim.current=null;}}}/>;
}
