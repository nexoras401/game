'use client';
import {useEffect} from 'react';
import {AudioManager} from '../services/audio/AudioManager';
export default function GlobalMusic(){
 useEffect(()=>{const music=new AudioManager();let activated=false;
 const mute=()=>{music.muted=localStorage.getItem('bubble.muted')==='true';if(music.master&&music.ctx)music.master.gain.setTargetAtTime(music.muted?0:.38,music.ctx.currentTime,.06);};
 const start=()=>{activated=true;music.init();mute();music.startMusic();};
 const visibility=()=>{if(document.hidden)music.stopMusic();else if(activated)start();};
 window.addEventListener('pointerdown',start,true);window.addEventListener('keydown',start,true);window.addEventListener('bubble-audio-change',mute);document.addEventListener('visibilitychange',visibility);
 return()=>{window.removeEventListener('pointerdown',start,true);window.removeEventListener('keydown',start,true);window.removeEventListener('bubble-audio-change',mute);document.removeEventListener('visibilitychange',visibility);music.dispose();};
 },[]);return null;
}
