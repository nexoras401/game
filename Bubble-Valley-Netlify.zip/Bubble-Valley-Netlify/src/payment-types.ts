export type DepositPayment={id:string;status:string;amountCents:number;bonusCents:number;totalCents:number;pixCopyPaste:string|null;expiresAt:string|null};
